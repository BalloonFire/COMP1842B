//reference: https://www.geeksforgeeks.org/build-a-todo-list-app-using-vuejs/
const app = new Vue({
    el: "#vue_app",
    data: {
        userInput: '',  //content of user input
        userInput2: '',  //content of user input 2 (category)
        list: [     //get from database
        ],
        errorMessage: '' //display error message
    },
    mounted: function () {
        //this function is called after all DOM elements rendered in HTML page
        this.$nextTick(function () {
            this.fetchList();
        })
    },
    methods: {
        async fetchList() {
            const response = await fetch("http://localhost:3000/todo/read_list");
            var response_json = await response.json();
            // console.log(response_json);
            this.list = response_json['data'];
        },
        save_new_item(newItem){
            //send data to Nodejs
            const requestOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(newItem)
            };
            fetch('http://localhost:3000/todo/create_new', requestOptions)
                .then(async response => {
                    const data = await response.json();
                    // console.log(data);
                    // check for error response
                    if (!response.ok || data.result === 'FAILED') {
                        // get error message from body or default to response status
                        const error = (data && data.message) || response.status;
                        return Promise.reject(error);
                    }
                    this.errorMessage = ''; //Remove error message if correctly
                    this.postId = data.id;
                    this.fetchList(); //Refresh list every time data is added.
                })
                .catch(error => {
                    this.errorMessage = error;
                    console.error('There was an error!', error);
                });
        },
        update_old_item(oldItem){
            //send data to Nodejs
            const requestOptions = {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(oldItem)
            };
            fetch('http://localhost:3000/todo/update', requestOptions)
                .then(async response => {
                    const data = await response.json();
                    // console.log(data);
                    // check for error response
                    if (!response.ok) {
                        // get error message from body or default to response status
                        const error = (data && data.message) || response.status;
                        return Promise.reject(error);
                    }
                    this.errorMessage = ''; //Remove error message if correctly
                    this.postId = data.id;
                    this.fetchList(); //Refresh list every time data is added.
                })
                .catch(error => {
                    this.errorMessage = error;
                    console.error('There was an error!', error);
                });
        },
        remove_old_Item(removedItem) {
            const requestOptions = {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(removedItem)
            };
            fetch(`http://localhost:3000/todo/delete`, requestOptions)
                .then(async response => {
                    const data = await response.json();
                    // console.log(data);
                    // check for error response
                    if (!response.ok) {
                        // get error message from body or default to response status
                        const error = (data && data.message) || response.status;
                        return Promise.reject(error);
                    }
                    this.errorMessage = ''; //Remove error message if correctly
                    this.postId = data.id;
                    this.fetchList(); //Refresh list every time data is added.
                })
                .catch(error => {
                    this.errorMessage = error;
                    console.error('There was an error!', error);
                });
        },
        addItem() {
            if (this.userInput.trim() !== '') {
                const newItem = {
                    id: generate_random_uuid(),
                    title: this.userInput.trim(),
                    category: this.userInput2.trim()
                };
                //this.list.push(newItem);
                this.save_new_item(newItem);    //put it in the list
                this.userInput = '';    //clear what user input
                this.userInput2 = '';    //clear what user input 2
            }
        },
        deleteItem(index) {
            const removedItem = {
                id: this.list[index].id
            };
            this.remove_old_Item(removedItem);
            //this.list.splice(index, 1); //remove 1 item at this position
        },
        editItem(index) {
            const editedTodo = prompt('Edit the todo:');    //display a popup to input new title
            if (editedTodo !== null && editedTodo.trim() !== '') {
                const oldItem = {
                    id: this.list[index].id,
                    title: editedTodo.trim()
                };
                //this.list.push(newItem);
                this.update_old_item(oldItem);
                //this.list[index].title = editedTodo.trim();
            }
        }
    }
});
