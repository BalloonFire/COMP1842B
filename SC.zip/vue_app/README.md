# vue_nodejs_express_mongodb_week5
Author: Martin Sang Do 2024
Sample project to teach Vue + Express in the course Web programming 2
